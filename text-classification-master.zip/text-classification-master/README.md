# text-classification
Machine Learning and NLP: Text Classification using python, scikit-learn and NLTK

Blog: https://medium.com/towards-data-science/machine-learning-nlp-text-classification-using-scikit-learn-python-and-nltk-c52b92a7c73a
